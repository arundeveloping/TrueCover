package Solution;

public class Customer {
private String name;
private static double [] measurements;



public Customer() {
	super();
	// TODO Auto-generated constructor stub
}
public Customer(String name, double[] measurements) {
	super();
	this.name = name;
	this.measurements = measurements;
}
public static double [] getMeasurement() {
	return measurements;
}
public void setMeasurement(double [] measurements) {
	this.measurements = measurements;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public double[] getMeasurements() {
	return measurements;
}
public void setMeasurements(double[] measurements) {
	this.measurements = measurements;
}

}
