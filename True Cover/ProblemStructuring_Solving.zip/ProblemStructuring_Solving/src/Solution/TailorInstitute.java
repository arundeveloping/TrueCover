package Solution;

public class TailorInstitute {
public static void main(String[] args) {
	double measurements[]= {2.4,4.5,52};
	Customer c=new Customer("AB", measurements);
	Tailor t1=new Tailor("Ram");
	Tailor t2=new Tailor("Rahim");
	Tailor t3=new Tailor("Mahavir");
	Tailor t4=new Tailor("Arjun");
	Tailor t5=new Tailor("Yeshu");
	Tailor [] t= {t2,t3,t4,t5};
	
	t1.stitch(5, c, t);
}
}
