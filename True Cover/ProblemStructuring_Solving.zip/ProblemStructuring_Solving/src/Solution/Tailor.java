package Solution;

public class Tailor {
private String name;
public Shirt stitch(double duration,Customer c,Tailor t[]) {
	Shirt s=new Shirt( c.getMeasurements());
	
	return s;
}
public Tailor(String name) {
	super();
	this.name = name;
}
}
