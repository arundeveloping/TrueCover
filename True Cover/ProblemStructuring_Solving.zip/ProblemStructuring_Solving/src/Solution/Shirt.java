package Solution;

public class Shirt {

private double [] measurements;



public Shirt(double[] measurements) {
	super();
	this.measurements = measurements;
}

public double[] getMeasurements() {
	return measurements;
}

public void setMeasurements(double[] measurements) {
	this.measurements = measurements;
}

}
